package hashtabledemo;

import java.util.LinkedList;

public class hashTable {
    private final int size;
    private final LinkedList<pair<String,String>>[] table;

    public hashTable(int size) {
        this.size = size;
        table = new LinkedList[size];
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList<>();
        }
    }

    public int hash(String key) {
        int hash = 0;
        for (int i = 0; i < key.length(); i++) {
            hash = (hash * 31 + key.charAt(i)) % size;
        }
        return hash;
    }

    public void insert(String key, String value) {
        int index = hash(key);
        table[index].add(new pair<>(key, value));
    }

    public String search(String key) {
        int index = hash(key);
        for (pair<String,String> entry : table[index]) {
            if (entry.key.equals(key)) {
                return entry.value;
            }
        }
        return null;
    }

    public int collisions(String key) {
        int index = hash(key);
        return table[index].size();
    }

    public int[] bucketFillStatus() {
        int[] fillStatus = new int[size + 1];
        for (LinkedList<pair<String,String>> bucket : table) {
            fillStatus[bucket.size()]++;
        }
        return fillStatus;
    }
}

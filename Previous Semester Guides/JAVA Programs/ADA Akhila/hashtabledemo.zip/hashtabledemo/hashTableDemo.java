package hashtabledemo;

import java.io.IOException;
import java.util.List;

import hashtabledemo.csvReader;
import hashtabledemo.hashTable;
import hashtabledemo.pair;

public class hashTableDemo {

    public static void main(String[] args) throws IOException {
        csvReader airports = new csvReader();
        List<pair<String,String>> codes = airports.read("C:/Users/mercy/Desktop/Steve_10_2/Java_1/hashtabledemo/airportCodes.csv");
        System.out.printf("read %d airport locations%n", codes.size());
        hashTable ht = new hashTable(701);
        codes.forEach(airport -> ht.insert(airport.key, airport.value));
        String[] keys = {"ORD", "LAX", "JFK", "LHR"};
        for (String key : keys) {
            System.out.printf("Collisions for key %s: %d%n", key, ht.collisions(key));
        }
    }
}

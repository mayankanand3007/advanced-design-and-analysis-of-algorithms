import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        String[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

        // Rowan student ID
        int[] studentIdDigits = {9, 1, 6, 4, 2, 3, 5, 9, 5};

        // Test 1: Sort the list <Integer, String>
        MinHeap<Integer, String> minHeap = new MinHeap<>();
        for (int i = 0; i < studentIdDigits.length; i++) {
            minHeap.insert(studentIdDigits[i], alphabet[i / 2]);
        }
        List<MinHeap.Data<Integer, String>> sortedList = minHeap.sort();
        System.out.println("Test 1: Sort the list <Integer, String>");
        for (MinHeap.Data<Integer, String> data : sortedList) {
            System.out.println("Key: " + data.key + ", Value: " + data.value);
        }

        System.out.println();

        // Test 2: Create a second list with swapped keys and values and sort it
        MinHeap<String, Integer> minHeap2 = new MinHeap<>();
        for (MinHeap.Data<Integer, String> data : sortedList) {
            minHeap2.insert(data.value, data.key);
        }
        List<MinHeap.Data<String, Integer>> sortedList2 = minHeap2.sort();
        System.out.println("Test 2: Sort the list <String, Integer> with swapped keys and values");
        for (MinHeap.Data<String, Integer> data : sortedList2) {
            System.out.println("Key: " + data.key + ", Value: " + data.value);
        }
    }
}

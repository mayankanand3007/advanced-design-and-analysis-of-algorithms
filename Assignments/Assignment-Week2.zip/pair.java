public class pair<T, U> {
    public final T key;
    public final U value;
    public pair(T key, U value) {
        this.key = key;
        this.value = value;
    }
}
